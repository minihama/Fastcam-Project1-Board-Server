package com.boardserver.boardserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoardserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
